# Document Q&A API

A Flask web app and API that answer questions using the local FAISS index built from `documents/tcs.pdf`. A browser interface is available at `/`, and a Postman collection is provided in `postman_collection.json`.

## Setup

Use Python 3.10 or newer. From the project folder in PowerShell:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Build the vector index from the PDF:

```powershell
python batchjob.py
```

Create a local `.env` file from the example and put your newly issued key there. The `.env` file is ignored by Git; do not commit it or share it in chat:

```powershell
Copy-Item .env.example .env
notepad .env
```

Replace the `OPENAI_API_KEY` placeholder in `.env`. The default model is `gpt-4o-mini`; change `OPENAI_MODEL` there if needed.

Start Flask:

```powershell
python -m flask --app app run --debug
```

Open `http://127.0.0.1:5000/` for the browser interface. The API endpoint is `POST http://127.0.0.1:5000/ask`. Send JSON with a `question` field:

```json
{
  "question": "What information is in the document?"
}
```

Import `postman_collection.json` into Postman and run **Ask a question**. The request expects a successful JSON response containing a `result` field.

If the index is missing, run `python batchjob.py` before asking a question. If the API key is missing, the endpoint returns a setup error. A previously exposed API key was removed from the source; revoke it and use a newly issued key in `.env`.
