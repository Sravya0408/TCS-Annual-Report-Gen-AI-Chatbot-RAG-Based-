'''
   REAL TIME JOB
   1. Create a flask function that takes question from postman
   2. Read the question from json
   3. Load local faiss db
   4. Ask the question to faiss db and get relevant chunks 
   5. Make a prompt with question and chunk
   6. Pass prompt to open ai llm
   7. Get response from open ai and return to postman or ui in json format.
'''
from pathlib import Path

from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
import os
from openai import APIError, OpenAI

load_dotenv(Path(__file__).resolve().parent / '.env', override=True)

app = Flask(__name__)


@app.get('/')
def home():
    return render_template('index.html')


@app.route('/ask', methods=['POST'])
def f1():
    data = request.get_json(silent=True) or {}
    question = data.get('question')
    if not isinstance(question, str) or not question.strip():
        return jsonify({'error': 'Provide a non-empty question.'}), 400
    if not os.getenv('OPENAI_API_KEY'):
        return jsonify({'error': 'Set OPENAI_API_KEY before asking a question.'}), 503

    index_path = Path(__file__).resolve().parent / 'faiss_index'
    if not (index_path / 'index.faiss').is_file():
        return jsonify({'error': 'The document index is missing. Run batchjob.py first.'}), 503

    embeddings = HuggingFaceEmbeddings(
        model_name='sentence-transformers/all-mpnet-base-v2'
    )
    my_vector_store = FAISS.load_local('faiss_index',
                                        embeddings,
                                        allow_dangerous_deserialization=True)
    docs = my_vector_store.similarity_search(question.strip())
    context = '\n\n'.join(doc.page_content for doc in docs)
    my_prompt = f'''Answer the question using only the context below. If the answer
is not present, say "Answer is not available in the chunk."

Question: {question.strip()}
Context: {context}'''

    client = OpenAI()
    try:
        response = client.responses.create(
            model=os.getenv('OPENAI_MODEL', 'gpt-4o-mini'),
            input=my_prompt,
        )
    except APIError as error:
        app.logger.warning(
            'OpenAI request failed: status=%s, code=%s, type=%s',
            error.status_code,
            error.code,
            type(error).__name__,
        )
        return jsonify({
            'error': 'OpenAI request failed.',
            'status': error.status_code,
            'code': error.code,
        }), 502

    return jsonify({'result': response.output_text})

