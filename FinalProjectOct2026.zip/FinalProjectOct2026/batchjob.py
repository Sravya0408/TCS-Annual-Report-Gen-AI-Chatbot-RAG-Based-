from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
import os

#step 1: Load pdf file store into my documents
file_path = os.path.join('documents','tcs.pdf')
loader = PyPDFLoader(file_path)
documents = loader.load()
print('Total Pages are..', len(documents))

#step 2: Convert to Chunks
splitter = RecursiveCharacterTextSplitter(chunk_size = 2000,
                                          chunk_overlap = 500,)
mychunks = splitter.split_documents(documents)
print('Total Chunks are..',len(mychunks))

#step 3: Create Embedding Model
embeddings  = HuggingFaceEmbeddings(model_name ='sentence-transformers/all-mpnet-base-v2')

#step 4: Create faiss db & store documents
vector_store = FAISS.from_documents(documents = mychunks,
                                    embedding = embeddings,)

#step 5: Store faiss db in some local place
vector_store.save_local('faiss_index') # This is our Database name
print("Successfully Saved Pdf into Faiss db...")

'''
   from real time python file, if you want to use faiss we need to load faiss.
   my_vector_store = FAISS.load_local('faiss_index',
                                       embeddings,
                                       allow_dangerous_deserialization = True)
   docs = my_vector_store.similarity_search(question)
'''